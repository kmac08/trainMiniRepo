ript for the Big Train Group Master Control Interface
"""